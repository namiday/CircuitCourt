import React, { Component } from 'react';
import {BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import 'antd/dist/antd.css';
// import { createBrowserHistory } from 'history';
import Home from './components/Home';
import Shop from './components/Shop';
import Manage from './components/Manage';
import './css/App.css';

class App extends Component {
  render() {
    return (
      <Router basename='/'>
        <Switch>
          <Route exact path='/' render={(props) => (<Home {...props}/>)} />
          <Route exact path='/shop/:id' render={(props) => (<Shop {...props}/>)} />
          <Route exact path='/manage/:id' render={(props) => (<Manage {...props}/>)} />
        </Switch>
      </Router>
    );
  }
}

export default App;
