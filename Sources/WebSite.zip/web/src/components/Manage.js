import React, { Component } from 'react';
import '../css/Manage.css';
import Header from './Header';
import Footer from './Footer';
import { Tabs, Button, Input } from 'antd';

const TabPane = Tabs.TabPane;



export default class Shop extends Component {
    state = {products: [], shop: ''}
    
    componentWillMount(){
        var self = this;    
        this.add = this.add.bind(this);
        this.remove = this.remove.bind(this);
        var url = 'http://ec2-34-247-50-129.eu-west-1.compute.amazonaws.com/getShop/' + this.props.match.params.id;
        fetch(url, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            }
        }).then(function(response){
            response.json().then(function(data) {
                console.log('shop', data)
                self.setState({shop: data})
            });
        })
        url = 'http://ec2-34-247-50-129.eu-west-1.compute.amazonaws.com/getProducts/' + this.props.match.params.id;
        fetch(url, {
        method: 'GET',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
        }
        }).then(function(response){
            response.json().then(function(data) {
                console.log('data', data);
                var products = [];
                data.forEach(function(element) {
                    products.push(element);
                });
                self.setState({products: products})
            });
        })
    }

    add(){
        return;
    }

    remove(){
        var prod = this.state.products;
        // prod.splice(i, 1);
        // this.setState({products:prod});
    }
   

    render() {
        
        var products = this.state.products;
        var shop = this.state.shop;
        var productsRender = [];
        for(var i = 0; i < products.length; i++){
            productsRender.push(
                <TabPane tab={products[i].name} key={i}>
                    {products[i].name} pour le prix de <b>{products[i].price}€</b>
                    <br /><br />
                    <Button onClick={this.remove} type="primary" icon="minus" size='large'>Supprimer</Button>
                    <br /><br />
                </TabPane>
            )
        };
        return (
        <div className="home">
            <Header/>
            <div className="">
                <div className="wrapper center">
                    <div className="cardHeader">
                        Gérer le magasin {shop.shopName} situé à {shop.shopCity}!
                    </div>
                    <div className="card">
                        <Tabs
                            defaultActiveKey="1"
                            tabPosition='top'
                        >
                            {productsRender}    
                            <TabPane tab="Ajouter un produit" key="ajouter">
                                Ajouter un produit
                                <br /><br />
                                <Input className="input" placeholder="élément" />
                                <br /><br />
                                <Input className="input" placeholder="Prix" />
                                <br /><br />
                                <Button onClick={this.add} type="primary" icon="plus" size='large'>Ajouter</Button>
                                <br /><br />
                            </TabPane>
                        </Tabs>
                    </div>
                    {/* <Button onClick={this.manage} type="primary" icon="edit" size='large'>Gérer ce shop</Button>
                    <Button onClick={this.contact} className="contact" type="primary" icon="mail" size='large'>Contact</Button> */}
                  
                </div>
            </div>
            <Footer/>

        </div>
        );
    }
}


