import React, { Component } from 'react';
import '../css/Shop.css';
import Header from './Header';
import Footer from './Footer';
import { Tabs, Button } from 'antd';

const TabPane = Tabs.TabPane;



export default class Shop extends Component {
    state = {products: [], shop: ''}
    
    componentWillMount(){
        var self = this;
        this.contact = this.contact.bind(this);
        this.manage = this.manage.bind(this);
        var url = 'http://ec2-34-247-50-129.eu-west-1.compute.amazonaws.com/getShop/' + this.props.match.params.id;
        fetch(url, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            }
        }).then(function(response){
            response.json().then(function(data) {
                console.log('shop', data)
                self.setState({shop: data})
            });
        })
        url = 'http://ec2-34-247-50-129.eu-west-1.compute.amazonaws.com/getProducts/' + this.props.match.params.id;
        fetch(url, {
        method: 'GET',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
        }
        }).then(function(response){
            response.json().then(function(data) {
                console.log('data', data);
                var products = [];
                data.forEach(function(element) {
                    products.push(element);
                });
                self.setState({products: products})
            });
        })
    }

    contact(){
        window.location.href = "mailto:" + this.state.shop.contacts;
    }

    manage(){
        window.location.href = "/manage/" + this.props.match.params.id;
    }

    render() {
        
        var products = this.state.products;
        var shop = this.state.shop;
        var productsRender = [];
        
        for(var i = 0; i < products.length; i++){
            productsRender.push(
                <TabPane tab={products[i].name} key={i}>Venez les goûter, venez vous procurer mes {products[i].name} pour la modique somme de <b>{products[i].price}€</b>!</TabPane>
            )
        };
        return (
        <div className="home">
            <Header/>
            <div className="">
                <div className="wrapper center">
                    <div className="cardHeader">
                        Bienvenue dans le magasin {shop.shopName} situé à {shop.shopCity}! Ici vous pouvez acheter: 
                    </div>
                    <div className="card">
                        <Tabs
                            defaultActiveKey="1"
                            tabPosition='top'
                            style={{ height: 220 }}
                        >
                            {productsRender}    
                        </Tabs>
                    </div>
                    <Button onClick={this.manage} type="primary" icon="edit" size='large'>Gérer ce shop</Button>
                    <Button onClick={this.contact} className="contact" type="primary" icon="mail" size='large'>Contact</Button>
                    <br /><br /><br />
                </div>
            </div>
            <Footer/>

        </div>
        );
    }
}


