import React, { Component } from 'react';
import '../css/Footer.css';

class Footer extends Component {

  render() {
    return (
      <div className="footer">
        CircuitCourt
      </div>
    );
  }
}

export default Footer;
