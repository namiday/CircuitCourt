import React, { Component } from 'react';
import '../css/Home.css';
import Header from './Header';
import Footer from './Footer';
import carte from '../img/gif.png';
import { Parallax } from 'react-parallax';
const styles = {
  fontFamily: 'sans-serif',
  textAlign: 'center',
};

class Home extends Component {

  componentWillMount(){
    // fetch('http://ec2-34-242-245-189.eu-west-1.compute.amazonaws.com:3000/users', {
    //   method: 'POST',
    //   headers: {
    //     'Accept': 'application/json',
    //     'Content-Type': 'application/json',
    //   },
    //   body: JSON.stringify({
    //     mail: 'yourValue'
    //   })
    // })
  }

  render() {
    return (
      <div className="home">
        <Header/>
        <div className="">
          <Parallax bgImage={require('../img/cc2.jpeg')}
            strength={400}>
            <div style={{height: 400}}>
              <div className="paralDiv">Reprenez le contrôle en vous fournissant chez le producteur. Trouvez des produits de qualité, en aidant le marché local</div>
            </div>
          </Parallax>
          <div className="divider"></div>
          <Parallax bgImage={require('../img/cc1.jpg')}
            strength={400}>
            <div style={{height: 400}}>
              <div className="paralDiv">Ou proposez à la vente ce que vous produisez. Devenez vous-même un producteur!</div>
            </div>
          </Parallax>
          <div className="divider"></div>
          <div className="wrapper center">
            <a href="/shop/1">
              <img src={carte} alt="Carte" className="map" />
            </a>
          </div>
        </div>
        <Footer/>

      </div>
    );
  }
}

export default Home;
